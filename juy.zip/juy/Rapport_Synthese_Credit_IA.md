# Rapport de Synthèse : Système de Scoring de Crédit IA
**Projet de Modernisation Bancaire - Inspiration Attijariwafa Bank**

---

### Résumé
Ce projet s'inscrit dans le cadre de la transformation digitale du secteur bancaire, visant à pallier les limites des méthodes traditionnelles d'octroi de crédit. La problématique centrale réside dans la lenteur et les risques opérationnels liés à la saisie manuelle et à l'analyse subjective des dossiers de prêt. L'objectif principal est de concevoir une plateforme automatisée capable de centraliser, traiter et évaluer l'éligibilité des clients en temps réel.

La méthodologie adoptée repose sur une architecture web robuste utilisant le framework Flask, intégrant deux piliers technologiques majeurs : un module de reconnaissance optique (OCR) pour l'extraction automatisée des données depuis des formulaires PDF, et un moteur prédictif basé sur des algorithmes de Machine Learning (Random Forest). Ce modèle a été entraîné pour identifier les profils à risque en s'appuyant sur des indicateurs financiers clés tels que les revenus, l'historique bancaire et le ratio d'endettement.

Les principaux résultats démontrent une fiabilité accrue dans l'extraction des métadonnées et une précision significative dans le scoring des dossiers, illustrée par une interface utilisateur intuitive inspirée de la charte graphique d'Attijariwafa Bank. En conclusion, ce système prouve que l'intégration de l'intelligence artificielle permet non seulement d'optimiser la productivité des analystes crédits, mais aussi de standardiser les décisions bancaires pour une meilleure maîtrise du risque.

**Mots-clés** : Intelligence Artificielle · Scoring de Crédit · OCR · Machine Learning · Transformation Digitale

---

### Abstract
This project is part of the digital transformation within the banking sector, aimed at overcoming the inefficiencies of traditional credit approval processes. The core problem addresses the significant operational risks and delays caused by manual data entry and subjective decision-making. The primary objective of this study is to develop an automated platform capable of centralizing, processing, and evaluating loan eligibility in real-time.

The methodology utilizes a robust web architecture built on the Flask framework, integrating two key technological pillars: an Optical Character Recognition (OCR) module for automated data extraction from PDF forms, and a predictive scoring engine powered by Machine Learning (Random Forest). This model was trained to detect high-risk profiles by analyzing critical financial indicators such as net income, credit history, and debt-to-income ratios.

Main results indicate a high degree of reliability in metadata extraction and significant precision in risk assessment, all presented through a professional user interface inspired by the Attijariwafa Bank design system. In conclusion, the system demonstrates that integrating artificial intelligence not only enhances the productivity of credit analysts but also standardizes decision-making processes, leading to more effective institutional risk management.

**Keywords**: Artificial Intelligence · Credit Scoring · OCR · Machine Learning · Digital Transformation

---

## Introduction Générale

### 1. Contexte et cadre général
Le domaine de la **Finance Technologique (FinTech)** connaît une transformation profonde portée par l'émergence de l'Intelligence Artificielle et de l'automatisation des processus. Dans ce contexte, la filière **IIR (Ingénierie Informatique et Réseaux) de l'EMSI** s'inscrit dans une démarche d'innovation visant à former des ingénieurs capables de concevoir des solutions technologiques répondant aux défis complexes du secteur bancaire moderne. Ce projet se situe à l'intersection de la Data Science et du Développement Web, cherchant à moderniser les systèmes d'octroi de crédit, piliers de l'économie marocaine.

### 2. Problématique
Malgré les avancées technologiques, de nombreuses institutions financières continuent de traiter les dossiers de crédit de manière semi-manuelle, ce qui engendre des délais importants et des risques opérationnels liés à la subjectivité humaine. 
**Question de recherche centrale :**
Comment automatiser l'extraction et l'analyse des dossiers de prêt afin d'optimiser le temps de traitement et d'accroître la précision des décisions d'éligibilité dans un contexte de transformation digitale bancaire ?

### 3. Objectifs du travail
Ce projet de fin d'année vise à atteindre les objectifs suivants :
*   **Objectif principal** : Développer une plateforme web intelligente capable de numériser, analyser et scorer automatiquement une demande de crédit.
*   **Objectif secondaire 1** : Concevoir et implémenter un module d'OCR robuste pour l'extraction de métadonnées depuis des formulaires PDF.
*   **Objectif secondaire 2** : Entraîner et intégrer un modèle de Machine Learning performant pour la prédiction du risque de crédit.
*   **Objectif secondaire 3** : Développer un tableau de bord analytique pour le suivi des indicateurs de performance (KPI) bancaires.

### 4. Démarche adoptée
L'approche adoptée suit une méthodologie hybride, combinant la démarche **CRISP-DM** pour le cycle de vie du modèle de Machine Learning (compréhension des données, modélisation, évaluation) et une approche de prototypage rapide pour le développement web sous Flask. Les outils utilisés incluent Python pour le backend, SQLAlchemy pour la persistance des données, et Chart.js pour la visualisation.

### 5. Structure du rapport
Le présent rapport est organisé comme suit :
1.  **Chapitre 1 : Revue de Littérature** : état de l'art du scoring bancaire et positionnement théorique de l'IA dans la finance.
2.  **Chapitre 2 : Méthodologie** : démarche technique, conception de l'OCR et choix architecturaux du modèle ML.
3.  **Chapitre 3 : Résultats et Analyse** : démonstration des livrables, tests de performance du modèle et métriques de scan.
4.  **Chapitre 4 : Discussion** : interprétation des résultats, limites du système et perspectives d'évolution.

---

---

## Chapitre 1 : Revue de Littérature

### 1.1 Contexte théorique et fondements disciplinaires
#### 1.1.1 Concepts et définitions clés
*   **Credit Scoring** : Méthode statistique permettant d'évaluer la probabilité qu'un emprunteur soit en défaut de paiement (Altman, 1968).
*   **Machine Learning (Apprentissage Automatique)** : Branche de l'IA permettant aux systèmes d'apprendre à partir de données pour identifier des motifs complexes (Samuel, 1959).
*   **OCR (Reconnaissance Optique de Caractères)** : Technologie de conversion de types différents de documents (PDF, images) en données éditables et exploitables (Mori et al., 1992).
*   **FinTech** : Utilisation de la technologie pour améliorer et automatiser les services financiers.

#### 1.1.2 Cadres théoriques mobilisés
L'approche repose sur le **Modèle de Scoring Comportemental** et le framework **CRISP-DM** (Cross-Industry Standard Process for Data Mining). Nous utilisons également le concept de **Digital Transformation Framework** pour situer l'automatisation de l'OCR comme un levier de performance opérationnelle.

### 1.2 État de l'art
#### 1.2.1 Tableau comparatif des approches existantes
| Auteur / Source | Approche proposée | Forces | Limites |
| :--- | :--- | :--- | :--- |
| **Score de FICO (Traditionnel)** | Modèles linéaires (Régression logistique) | Très interprétable, standard industriel | Rigide, peu performant sur les données non-linéaires |
| **Zest AI (Moderne)** | Machine Learning (Black-box) | Très haute précision, analyse multi-sources | Manque de transparence ("Black box"), coût élevé |
| **Amazon Textract** | Cloud OCR de masse | Très puissant, gère plusieurs formats | Dépendance au Cloud, coût par page, confidentialité |
| **Notre Solution** | Hybride OCR Local + ML | Sécurité des données, temps réel, design métier | Nécessite un entraînement sur des formulaires spécifiques |

#### 1.2.2 Technologies et outils du domaine
Nous avons comparé **Django** vs **Flask** et avons choisi Flask pour sa modularité avec les bibliothèques de Data Science. Pour l'OCR, **PyPDF2** a été retenu pour sa légèreté par rapport à **Tesseract**, car nos documents sont des PDF numériques structurés.

### 1.3 Analyse critique des travaux existants
#### 1.3.1 Points forts identifiés
*   Standardisation des processus de décision.
*   Capacité d'analyse de gros volumes de données.

#### 1.3.2 Lacunes et axes d'amélioration
*   **Accessibilité** : Les solutions actuelles sont souvent trop complexes ou trop chères pour les banques locales.
*   **Automatisation de bout en bout** : Peu de solutions intègrent nativement l'OCR et le Scoring dans un flux de travail unique et simplifié.

### 1.4 Positionnement du travail
Ce projet se différencie par son intégration verticale "tout-en-un" :
*   **Originalité 1** : Adaptation de l'OCR aux formulaires bancaires spécifiques.
*   **Originalité 2** : Interface utilisateur simplifiée pour un déploiement immédiat en agence.
*   **Contribution spécifique** : Un outil d'aide à la décision qui ne remplace pas l'humain mais lui fournit une analyse pré-remplie et un score de confiance.

---

## Gestion de Projet et Entrepreneuriat (ENT)

### ENT.1.1 Problème et cible visée
| Champ | Détails |
| :--- | :--- |
| **Problème résolu** | Lenteur administrative et erreurs de saisie dans l'octroi de crédit. |
| **Utilisateurs cibles** | Banquiers de détail, analystes de risques, agences de microfinance. |
| **Segment de marché** | B2B (Secteur Bancaire et Financier). |
| **Urgence du besoin** | 4/5 (Forte pression sur la digitalisation bancaire). |
| **Taille du marché** | Marché national en pleine transition numérique. |

### ENT.1.2 Proposition de valeur unique (Value Proposition)
"Notre **système de scoring IA** aide les **établissements financiers** à **réduire le temps d'analyse des dossiers de 80%**, contrairement aux **processus manuels traditionnels**, en offrant une **extraction automatique par OCR et une prédiction de risque instantanée**."

### ENT.2 Business Model Canvas
*   **Partenaires clés** : Fournisseurs d'infrastructure Cloud, éditeurs de logiciels bancaires.
*   **Activités clés** : Développement ML, maintenance OCR, support technique.
*   **Proposition de valeur** : Gain de temps, réduction du risque de défaut, interface métier intuitive.
*   **Relation clients** : Support dédié, formation des analystes.
*   **Segments clients** : Banques, Institutions de micro-crédit.
*   **Ressources clés** : Modèles ML, expertise métier bancaire, infrastructure tech.
*   **Canaux** : Vente directe B2B, partenariats avec des cabinets de conseil.
*   **Coûts** : R&D, maintenance serveurs, salaires.
*   **Revenus** : Licence annuelle ou abonnement SaaS par volume de scans.

### ENT.3 Analyse de marché et concurrence
#### ENT.3.1 Analyse SWOT
*   **Forces** : Intégration OCR/ML, design personnalisé, rapidité.
*   **Faiblesses** : Dépendance à la qualité des PDF source, marque nouvelle.
*   **Opportunités** : Accélération de la digitalisation bancaire post-COVID.
*   **Menaces** : Entrée de grands acteurs (Amazon/Google) sur le segment OCR.

### ENT.4 Modèle économique et projections
*   **Tarification** : Modèle SaaS à 5000 MAD/mois par agence ou Licence Entreprise.
*   **Rentabilité** : Point d'équilibre estimé à **14 mois** avec un parc de 15 agences clientes.

---

## 1. Résumé Exécutif
Ce projet présente une solution innovante de gestion et d'analyse des demandes de crédit. En combinant l'**OCR** (Reconnaissance Optique de Caractères) et le **Machine Learning**, l'application automatise l'extraction de données et l'évaluation du risque client, réduisant ainsi le temps de traitement de plusieurs jours à quelques secondes.

## 2. Contexte et Problématique
Dans un environnement financier de plus en plus compétitif, la rapidité de décision est un facteur clé de différenciation.
*   **Problème** : Les processus manuels ralentissent l'octroi de crédits et augmentent les risques opérationnels.
*   **Solution** : Une plateforme centralisée permettant de scanner des dossiers PDF, d'extraire les données financières et de prédire l'éligibilité via un modèle prédictif entraîné sur des données historiques.

## 3. Fonctionnalités Clés
### A. Module OCR & Saisie Intelligente
*   Extraction automatique des informations (Nom, CIN, Salaire, Montant demandé) depuis des formulaires PDF.
*   Validation en temps réel des données extraites.

### B. Moteur de Scoring (IA)
*   Analyse du profil de risque basée sur un modèle de **Machine Learning**.
*   Génération d'un **Score de Confiance** (ex: 89%) pour justifier la décision d'approbation ou de rejet.

### C. Dashboard Management
*   Visualisation analytique des demandes par ville et par produit (Chart.js).
*   Suivi du volume de crédit et des taux d'acceptation en temps réel.

### D. Sécurité & Administration
*   Authentification forte et hachage des mots de passe (Bcrypt).
*   Contrôle d'accès basé sur les rôles (Banquier vs Directeur).

## 4. Architecture Technique
*   **Langage** : Python 3.10
*   **Framework Web** : Flask (Architecture MVC)
*   **Base de données** : SQLAlchemy (SQLite pour la portabilité)
*   **Intelligence Artificielle** : Scikit-learn (Algorithme de classification)
*   **Traitement PDF** : PyPDF2 / Re (Regex avancées)
*   **Interface (UI/UX)** : HTML5/CSS3 (Design Système Attijari) et Chart.js

## 5. Valeur Ajoutée & Impact
1.  **Productivité** : Réduction drastique des erreurs de saisie.
2.  **Expérience Client** : Réponse quasi-instantanée lors du rendez-vous bancaire.
3.  **Gestion du Risque** : Standardisation des critères d'octroi de crédit, moins de place à la subjectivité.

## 6. Conclusion et Perspectives
Le système actuel pose les bases d'une banque "Smart & Digital". Les prochaines étapes incluent l'intégration d'API de vérification d'identité en temps réel et l'utilisation de modèles d'IA plus complexes (Deep Learning) pour l'analyse prédictive du comportement de remboursement.

---
*Document généré pour la présentation de fin de projet.*
