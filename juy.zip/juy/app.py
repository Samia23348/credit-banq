import os
import pickle
import pandas as pd
import re
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_bcrypt import Bcrypt
from werkzeug.utils import secure_filename
import PyPDF2

# Initialize App
app = Flask(__name__)
app.config['SECRET_KEY'] = 'super-secret-key-pour-fintech'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///bank.db'
app.config['UPLOAD_FOLDER'] = 'uploads'

# Create uploads folder if not exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Extensions
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Load model artifacts
with open('model_artifacts.pkl', 'rb') as f:
    artifacts = pickle.load(f)

model = artifacts['model']
scaler = artifacts['scaler']
feature_cols = artifacts['feature_cols']

# ----------------- DB Models -----------------
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False, default='banker')

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

class LoanApplication(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False)
    prenom = db.Column(db.String(100), nullable=False)
    cin = db.Column(db.String(50), nullable=False)
    telephone = db.Column(db.String(20))
    ville = db.Column(db.String(100))
    situation_pro = db.Column(db.String(100))
    salaire_net = db.Column(db.Float)
    type_credit = db.Column(db.String(50))
    montant_demande = db.Column(db.Float)
    duree_remboursement = db.Column(db.Integer)
    historique_bancaire = db.Column(db.String(100))
    
    is_eligible = db.Column(db.Boolean)
    probability = db.Column(db.Float)
    proposed_amount = db.Column(db.Float, nullable=True)
    
    banker_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    created_at = db.Column(db.DateTime, server_default=db.func.now())

# Initialize DB
with app.app_context():
    db.create_all()
    if not User.query.filter_by(username='directeur').first():
        hashed_pw = bcrypt.generate_password_hash('admin123').decode('utf-8')
        admin = User(username='directeur', password=hashed_pw, role='admin')
        db.session.add(admin)
        db.session.commit()

# ----------------- Routes -----------------

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('admin' if user.role == 'admin' else 'home'))
        flash('Identifiants invalides', 'danger')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/admin', methods=['GET', 'POST'])
@login_required
def admin():
    if current_user.role != 'admin': return redirect(url_for('home'))
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if not User.query.filter_by(username=username).first():
            hashed_pw = bcrypt.generate_password_hash(password).decode('utf-8')
            db.session.add(User(username=username, password=hashed_pw, role='banker'))
            db.session.commit()
            flash('Banquier créé!', 'success')
    bankers = User.query.filter_by(role='banker').all()
    return render_template('admin.html', bankers=bankers)

@app.route('/')
@login_required
def home():
    if current_user.role == 'admin': return redirect(url_for('dashboard'))
    return render_template('index.html', username=current_user.username)

@app.route('/dashboard')
@login_required
def dashboard():
    total_apps = LoanApplication.query.count()
    accepted = LoanApplication.query.filter_by(is_eligible=True).count()
    rejected = LoanApplication.query.filter_by(is_eligible=False).count()
    total_amount = db.session.query(db.func.sum(LoanApplication.montant_demande)).filter_by(is_eligible=True).scalar() or 0
    recent_apps = LoanApplication.query.order_by(LoanApplication.created_at.desc()).limit(10).all()
    
    # Aggregations for charts
    cities_data = db.session.query(LoanApplication.ville, db.func.count(LoanApplication.id)).group_by(LoanApplication.ville).all()
    types_data = db.session.query(LoanApplication.type_credit, db.func.count(LoanApplication.id)).group_by(LoanApplication.type_credit).all()
    
    return render_template('dashboard.html', 
                           total=total_apps, 
                           accepted=accepted, 
                           rejected=rejected, 
                           total_amount=total_amount, 
                           recent_apps=recent_apps,
                           cities_labels=[x[0] for x in cities_data if x[0]],
                           cities_values=[x[1] for x in cities_data if x[0]],
                           types_labels=[x[0] for x in types_data if x[0]],
                           types_values=[x[1] for x in types_data if x[0]])

@app.route('/history')
@login_required
def history():
    apps = LoanApplication.query.order_by(LoanApplication.created_at.desc()).all() if current_user.role == 'admin' else LoanApplication.query.filter_by(banker_id=current_user.id).order_by(LoanApplication.created_at.desc()).all()
    return render_template('history.html', applications=apps)

@app.route('/predict', methods=['POST'])
@login_required
def predict():
    try:
        data = request.json
        income = float(data.get('salaire_net', 0))
        requested = float(data.get('montant_demande', 0))
        loan_k = requested / 1000 if requested > 1000 else requested
        term = float(data.get('duree_remboursement', 360))
        hist = 1.0 if data.get('historique_bancaire') in ['Excellent', 'Correct'] else 0.0
        
        # ML Input
        input_df = pd.DataFrame(columns=feature_cols)
        input_df.loc[0] = 0
        input_df['ApplicantIncome'] = income
        input_df['CoapplicantIncome'] = 0
        input_df['LoanAmount'] = loan_k
        input_df['Loan_Amount_Term'] = term
        input_df['Credit_History'] = hist
        
        # Default categorical
        for col in ['Gender_Male', 'Married_Yes', 'Property_Area_Semiurban']:
            if col in feature_cols: input_df[col] = 1
            
        num_cols = ['ApplicantIncome', 'CoapplicantIncome', 'LoanAmount', 'Loan_Amount_Term']
        input_df[num_cols] = scaler.transform(input_df[num_cols])
        
        is_eligible = bool(model.predict(input_df)[0] == 1)
        prob = float(model.predict_proba(input_df)[0][1])
        
        proposed = min(requested, (income * 0.35) * term)
        
        new_app = LoanApplication(
            nom=data.get('nom'), prenom=data.get('prenom'), cin=data.get('cin'),
            telephone=data.get('telephone'), ville=data.get('ville'),
            situation_pro=data.get('situation_pro'), salaire_net=income,
            type_credit=data.get('type_credit'), montant_demande=requested,
            duree_remboursement=int(term), historique_bancaire=data.get('historique_bancaire'),
            is_eligible=is_eligible, probability=prob, proposed_amount=float(proposed),
            banker_id=current_user.id
        )
        db.session.add(new_app)
        db.session.commit()
        
        return jsonify({'eligible': is_eligible, 'probability': prob, 'proposed_amount': int(proposed)})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/scan', methods=['POST'])
@login_required
def scan():
    file = request.files.get('file')
    if not file or not file.filename.endswith('.pdf'): return jsonify({'error': 'PDF requis'}), 400
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
    file.save(filepath)
    
    text = ""
    try:
        with open(filepath, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            for p in reader.pages: text += p.extract_text() + "\n"
    except: pass
    os.remove(filepath)
    
    print(f"DEBUG EXTRACTED TEXT:\n{text}")
    
    # OCR Logic with more robust patterns
    # OCR Logic with stricter multiline patterns
    # OCR Logic with colon-focused separators
    patterns = {
        'nom': [r'Nom.*?:+\s*([^\n]+)'],
        'prenom': [r'Pr.?.?nom.*?:+\s*([^\n]+)'],
        'cin': [r'CIN.*?:+\s*([^\n]+)'],
        'telephone': [r'(?:T.?.?l|GSM|Phone).*?:+\s*([^\n]+)'],
        'ville': [r'Ville.*?:+\s*([^\n]+)'],
        'situation_pro': [r'(?:Situation|Profession).*?:+\s*([^\n]+)'],
        'salaire_net': [r'(?:Salaire|Revenu|Income).*?:+\s*([^\n]+)'],
        'type_credit': [r'(?:Type|Cr.?.?dit).*?:+\s*([^\n]+)'],
        'montant_demande': [r'(?:Montant|Amount).*?:+\s*([^\n]+)'],
        'duree_remboursement': [r'(?:Dur.?.?e|Term).*?:+\s*([^\n]+)'],
        'historique_bancaire': [r'(?:Historique|History).*?:+\s*([^\n]+)']
    }
    
    res = {}
    for k, pats in patterns.items():
        for p in pats:
            # Use MULTILINE to make ^ match start of lines
            m = re.search(p, text, re.IGNORECASE | re.MULTILINE)
            if m:
                v = m.group(1).strip()
                # Clean numeric values
                if k in ['salaire_net', 'montant_demande']:
                    v = v.replace(' ', '').replace(',', '').replace('DH', '').replace('dh', '').strip()
                
                res[k] = v
                
                # Normalization for select inputs
                v_up = v.upper()
                if k == 'situation_pro':
                    if 'CDI' in v_up: res[k] = 'CDI'
                    elif 'CDD' in v_up: res[k] = 'CDD'
                    elif 'FONCTION' in v_up or 'ETAT' in v_up: res[k] = 'Fonctionnaire'
                    elif 'AUTO' in v_up or 'ENTREPR' in v_up: res[k] = 'Auto-entrepreneur'
                    elif 'INDEP' in v_up or 'LIB' in v_up: res[k] = 'Independant'
                
                if k == 'type_credit':
                    if 'IMMOB' in v_up: res[k] = 'Immobilier'
                    elif 'AUTO' in v_up: res[k] = 'Automobile'
                    elif 'CONSOM' in v_up: res[k] = 'Consommation'
                    elif 'PROF' in v_up: res[k] = 'Professionnel'
                
                if k == 'historique_bancaire':
                    if 'EXCELL' in v_up: res[k] = 'Excellent'
                    elif 'CORRECT' in v_up or 'ACTIF' in v_up: res[k] = 'Correct'
                    elif 'LITIG' in v_up or 'MAUVAIS' in v_up: res[k] = 'Litigieux'
                
                if k == 'duree_remboursement':
                    digits = re.findall(r'\d+', v)
                    if digits: res[k] = digits[0]
                
                break
    return jsonify({'success': True, 'data': res})

@app.route('/delete_application/<int:app_id>', methods=['POST'])
@login_required
def delete_application(app_id):
    application = LoanApplication.query.get_or_404(app_id)
    if current_user.role != 'admin' and application.banker_id != current_user.id: return redirect(url_for('history'))
    db.session.delete(application)
    db.session.commit()
    return redirect(url_for('history'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
